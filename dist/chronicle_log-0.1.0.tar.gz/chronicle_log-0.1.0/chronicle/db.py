# chronicle/db.py
import sqlite3
import os
from pathlib import Path
from datetime import datetime

DB_DIR = Path.home() / ".chronicle"
DB_PATH = DB_DIR / "logbook.db"

def get_connection():
    DB_DIR.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS entries (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            category  TEXT NOT NULL DEFAULT 'general',
            title     TEXT,
            content   TEXT NOT NULL,
            mood      TEXT,
            tags      TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_timestamp ON entries(timestamp);
        CREATE INDEX IF NOT EXISTS idx_category  ON entries(category);
    """)
    conn.commit()
    conn.close()

def add_entry(content: str, category: str = "general",
              title: str = None, mood: str = None, tags: list = None):
    conn = get_connection()
    timestamp = datetime.now().isoformat(sep=" ", timespec="seconds")
    tags_str = ",".join(tags) if tags else None
    conn.execute(
        "INSERT INTO entries (timestamp, category, title, content, mood, tags) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (timestamp, category, title, content, mood, tags_str)
    )
    conn.commit()
    conn.close()

def get_entries(limit: int = 20, category: str = None,
                search: str = None, date: str = None):
    conn = get_connection()
    query = "SELECT * FROM entries WHERE 1=1"
    params = []
    if category:
        query += " AND category = ?"
        params.append(category)
    if search:
        query += " AND (content LIKE ? OR title LIKE ? OR tags LIKE ?)"
        params += [f"%{search}%", f"%{search}%", f"%{search}%"]
    if date:
        query += " AND timestamp LIKE ?"
        params.append(f"{date}%")
    query += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return rows

def get_stats():
    conn = get_connection()
    stats = {}
    stats["total"] = conn.execute("SELECT COUNT(*) FROM entries").fetchone()[0]
    stats["by_category"] = conn.execute(
        "SELECT category, COUNT(*) as n FROM entries GROUP BY category"
    ).fetchall()
    stats["first_entry"] = conn.execute(
        "SELECT timestamp FROM entries ORDER BY timestamp ASC LIMIT 1"
    ).fetchone()
    conn.close()
    return stats
