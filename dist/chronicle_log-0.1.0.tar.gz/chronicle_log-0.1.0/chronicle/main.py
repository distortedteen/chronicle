# chronicle/main.py
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from typing import Optional, List
from chronicle.db import init_db, add_entry, get_entries, get_stats
from chronicle.export import export_markdown, export_json

app = typer.Typer(
    name="chronicle",
    help="📖 Chronicle — Log your founder journey, one entry at a time.",
    add_completion=False
)
console = Console()

CATEGORIES = ["idea", "build", "learn", "fail", "win", "research", "general"]
MOODS = ["🔥 fire", "😤 grind", "😌 calm", "😩 stuck", "🎯 focused", "🤔 thinking"]

@app.callback(invoke_without_command=True)
def startup(ctx: typer.Context):
    init_db()
    if ctx.invoked_subcommand is None:
        console.print(Panel(
            "[bold cyan]Chronicle[/bold cyan] — Your founder's logbook\n"
            "[dim]Run [bold]chronicle --help[/bold] to see all commands[/dim]",
            border_style="cyan"
        ))

@app.command("log")
def log_entry(
    content: str = typer.Argument(..., help="Your log entry"),
    category: str = typer.Option("general", "-c", "--category",
                                  help=f"Category: {', '.join(CATEGORIES)}"),
    title: Optional[str] = typer.Option(None, "-t", "--title", help="Optional title"),
    mood: Optional[str] = typer.Option(None, "-m", "--mood", help="Your mood/energy"),
    tags: Optional[List[str]] = typer.Option(None, "--tag", help="Add tags (repeat for multiple)")
):
    """📝 Log a new entry."""
    add_entry(content, category=category, title=title, mood=mood, tags=tags)
    console.print(f"[green]✓[/green] Entry logged under [bold]{category}[/bold]")

@app.command("idea")
def log_idea(content: str = typer.Argument(..., help="Your idea")):
    """💡 Quick-log an idea."""
    add_entry(content, category="idea")
    console.print("[yellow]💡[/yellow] Idea captured.")

@app.command("win")
def log_win(content: str = typer.Argument(..., help="What did you achieve?")):
    """🏆 Log a win, no matter how small."""
    add_entry(content, category="win")
    console.print("[bold green]🏆 WIN logged. Keep going.[/bold green]")

@app.command("fail")
def log_fail(content: str = typer.Argument(..., help="What went wrong?")):
    """📉 Log a failure or lesson learned."""
    add_entry(content, category="fail")
    console.print("[dim red]📉 Failure logged. This is data, not defeat.[/dim red]")

@app.command("show")
def show_entries(
    limit: int = typer.Option(10, "-n", "--limit", help="Number of entries to show"),
    category: Optional[str] = typer.Option(None, "-c", "--category"),
    search: Optional[str] = typer.Option(None, "-s", "--search"),
    date: Optional[str] = typer.Option(None, "-d", "--date", help="Filter by date: YYYY-MM-DD")
):
    """📋 Show your log entries."""
    entries = get_entries(limit=limit, category=category, search=search, date=date)
    if not entries:
        console.print("[dim]No entries found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold cyan",
                  border_style="dim", expand=True)
    table.add_column("ID", style="dim", width=4)
    table.add_column("Timestamp", style="dim", width=20)
    table.add_column("Category", width=10)
    table.add_column("Title / Content")
    table.add_column("Tags", style="dim", width=20)

    CATEGORY_COLORS = {
        "idea": "yellow", "build": "cyan", "learn": "blue",
        "fail": "red", "win": "green", "research": "magenta", "general": "white"
    }

    for e in entries:
        color = CATEGORY_COLORS.get(e["category"], "white")
        display = e["title"] if e["title"] else (
            e["content"][:70] + "..." if len(e["content"]) > 70 else e["content"]
        )
        table.add_row(
            str(e["id"]),
            e["timestamp"],
            f"[{color}]{e['category']}[/{color}]",
            display,
            e["tags"] or ""
        )
    console.print(table)

@app.command("stats")
def show_stats():
    """📊 Show your journey statistics."""
    stats = get_stats()
    first = stats["first_entry"]["timestamp"] if stats["first_entry"] else "N/A"
    console.print(Panel(
        f"[bold]Total Entries:[/bold] {stats['total']}\n"
        f"[bold]Journey Started:[/bold] {first}",
        title="[bold cyan]Chronicle Stats[/bold cyan]",
        border_style="cyan"
    ))
    if stats["by_category"]:
        table = Table(show_header=True, header_style="bold", border_style="dim")
        table.add_column("Category")
        table.add_column("Entries", justify="right")
        for row in stats["by_category"]:
            table.add_row(row["category"], str(row["n"]))
        console.print(table)

@app.command("export")
def export_entries(
    format: str = typer.Option("markdown", "-f", "--format",
                                help="Export format: markdown | json"),
    output: str = typer.Option("chronicle_export", "-o", "--output",
                                help="Output filename (no extension)")
):
    """📤 Export your log to Markdown or JSON."""
    entries = get_entries(limit=99999)
    if format == "markdown":
        path = export_markdown(entries, output)
    elif format == "json":
        path = export_json(entries, output)
    else:
        console.print("[red]Unknown format. Use 'markdown' or 'json'[/red]")
        return
    console.print(f"[green]✓[/green] Exported to [bold]{path}[/bold]")

if __name__ == "__main__":
    app()
