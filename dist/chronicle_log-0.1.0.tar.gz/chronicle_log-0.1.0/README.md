# Chronicle 📖

> Log the journey. Tell the story.

Chronicle is a minimal CLI logbook built for founders, builders, and solo makers.
Log your ideas, wins, failures, and progress — with accurate timestamps — as you build.

## Install

pip install chronicle-log

## Usage

chronicle log "Had a breakthrough on the auth flow" -c build
chronicle idea "What if we added voice logging via whisper?"
chronicle win "First real user signed up"
chronicle fail "Shipped a bug that deleted sessions. Lesson: always backup."
chronicle show --limit 20
chronicle stats
chronicle export --format markdown

## Why?

Built by a founder, for founders. Every entry you make today
becomes the raw material of the story you'll tell tomorrow.

## License

MIT — free forever.
